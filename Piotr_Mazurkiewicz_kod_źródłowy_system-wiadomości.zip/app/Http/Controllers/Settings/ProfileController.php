<?php

namespace App\Http\Controllers\Settings;

class ProfileController
{
    public function edit() {}

    public function update() {}

    public function destroy() {}
}
